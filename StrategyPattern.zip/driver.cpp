
#include <iostream>
#include "PlayerStrategy.h"

using namespace std;

int main() {
	Player* p1 = new Player("Mark");
	Player* p2 = new Player("Jason");
	Territory* ca = new Territory("Canada", 5, p1);
	Territory* usa = new Territory("USA", 8, p1);
	Territory* sp = new Territory("Spain", 8, p1);
	Territory* fr = new Territory("France", 7, p1);
	Territory* me = new Territory("Mexico", 3, p2);
	Territory* ger = new Territory("Germany", 8, p2);
	Territory* uk = new Territory("UK", 7, p2);
	Territory* cn = new Territory("China", 10, p2);
	ca->addNeighbor(usa);
	ca->addNeighbor(cn);
	cn->addNeighbor(ca);
	cn->addNeighbor(sp);
	sp->addNeighbor(cn);
	sp->addNeighbor(ger);
	sp->addNeighbor(fr);
	fr->addNeighbor(sp);
	fr->addNeighbor(ger);
	fr->addNeighbor(uk);
	uk->addNeighbor(me);
	uk->addNeighbor(fr);
	me->addNeighbor(usa);
	me->addNeighbor(uk);
	usa->addNeighbor(me);
	usa->addNeighbor(ca);
	usa->addNeighbor(ger);
	ger->addNeighbor(usa);
	ger->addNeighbor(fr);
	ger->addNeighbor(sp);
	ger->addNeighbor(cn);
	p1->addTerritory(ca);
	p1->addTerritory(usa);
	p1->addTerritory(sp);
	p1->addTerritory(fr);
	p2->addTerritory(me);
	p2->addTerritory(ger);
	p2->addTerritory(uk);
	p2->addTerritory(cn);

	cout << "--------------------------";
	cout << "Testing for 2 players";
	cout << "--------------------------" << endl;
	p1->setStrategy(new Benevolent());
	p1->executeStrategy();
	cout << "---------------------------------------------------"<<endl;
	p2->setStrategy(new Benevolent());
	p2->executeStrategy();



	system("PAUSE");
	return 0;
}