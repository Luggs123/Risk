
#include <iostream>
#include "PlayerStrategy.h"


void Benevolent::execute(Player* p) {
	cout << "Benevolent strategy executed."<<endl;
	cout << "Player " << p->getId() << " now own the following:" << endl;
	p->showTerritory();
	cout << endl;
	p->reinforceToWeak();

}