//
// Created by Michael Wu on 2018-11-30.
//

#include "Driver.h"
#include "../Tournament/Tournament.h"

int driver::tournament_driver() {
    Tournament::begin_tournament();
}