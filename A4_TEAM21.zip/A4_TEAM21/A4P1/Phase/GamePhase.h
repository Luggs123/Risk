//
// Created by Michael Wu on 2018-11-17.
//

#ifndef RISK_GAMEPHASE_H
#define RISK_GAMEPHASE_H

enum GamePhase {ATTACK, REINFORCEMENT, FORTIFY};

#endif //RISK_GAMEPHASE_H
