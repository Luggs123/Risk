//edited by YINGJIE ZHOU
#pragma once

#include <vector>
#include <iostream>
#include <string>

#include "../Dice/Dice.h"
#include "../Map/Map.h"
#include "../Deck/Hand.h"

class Player {

private:
	//int check_reinforceAmout();// ToDo: calculate the number of troops a Player get
	int check_continents();// ToDo: check if this Player owned continents
	int get_troops(Territory &x);// TODO: get the amount of troops for a specific territory
	void add_troops(Territory &x, int n);// TODO: add troops to a specific territory
	std::vector<Territory*> controlled;// a vector of Territories owned by Player
	
	

	int playerID;//old
	std::string player_name;
	int free_troops;//the number of troops Player can placed as they want
	Hand* card_on_hand; //the Object that takes the Player's cards on hand
	Dice D;// the DICE Object for the Player


public:
	Player();
	Player(int ID);//old
	Player(std::string n);//new
	~Player();
	void round();

	void setPID(int ID);//old
	int getPID();//old
	void set_name(std::string n);//new
	void show_name();//new
	void set_free_troops(int num);
	int get_free_troops();
	void showcardsonHand();

	void add_territory(Territory &x);//add new territory that Player just occupied
	void lose_territory(Territory &x);//remove the territory that Player just lose
	void show_territory();
	void attackroll();
	void defenceroll();
    std::vector<Territory*>& get_own_territories();
	void add_troops(int index, int troop);

	Territory* get_controlled();//A2_P4&6
	int get_number_controlled();//A2_P4&6

	void reinforce();
	void attack();
	void fortify();

	void fight(Territory* att, Territory* def);
	void movingArmy();
};