#pragma once

#include <vector>
#include <string>

using namespace std;

class Player;
class strategy;

class Strategy {
public:
	virtual void execute(Player* p) = 0;
};


class Random :public Strategy {
public:
	void execute(Player* p);
};

class Territory {
private:
	Player* owner;
	string name;
	int troops;
	vector<Territory*> neighbors;

public:
	Territory(string name);
	Territory(string na, int trp, Player* owner);

	// Accessors
	int getTroops();
	string getName();
	vector<Territory*> getNeighbors();
	Player* getOwner();


	// Mutators
	void setOwner(Player* owner);
	void setTroops(int troops);
	void addNeighbor(Territory* t);

};

class Player {

private:
	vector<Territory *> controlled;
	string PlayerID;
	Strategy* strategy;

public:
	Player();
	Player(string id);

	//strategy methods added below
	Player(string id,Strategy* init);
	void setStrategy(Strategy *newStrategy);
	void executeStrategy();
	//.........................

	string getId();
	void setId(int id);
	void attack();
	void addTerritory(Territory* x);
	void showTerritory();
	void fight(Territory* att, Territory* def);
	void reinforceToWeak();
	void movingArmy();

	void reinforceRandom();
	void attackRandom();
	void fotifyRandom();

};

class Dice {

public:
	string name;
	Dice();
	Dice(string nam);
	int totalRolled;
	int currentRolled;
	int currentResult[3];
	int diceStats[7];
	void getPercentage();
	void roll(int num);
	void game();
	void sortResult();
};


