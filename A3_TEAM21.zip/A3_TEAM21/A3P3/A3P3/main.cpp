#include "Drivers/Driver.h"


int main() {
//    driver::dice_driver();
//    driver::map_driver();
//    driver::map_loader_driver();
//    driver::player_driver();
//    driver::deck_driver();
//    driver::game_start_driver();
//    driver::startup_driver();
//    driver::main_game_driver();
//    driver::reinforcement_driver();
//    driver::fortification_driver();
//    driver::benevolent_strategy_driver();
//    driver::attack_driver();
	  driver::game_statics_observer_driver();
    return 0;
}