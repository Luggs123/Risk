#include"GameStaticsObserver.h"

GameStaticsObserver::~GameStaticsObserver()
{
}

GameStaticsObserver::GameStaticsObserver()
{
}
