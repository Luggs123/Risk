AuCircles
---------
map for Conquest (www.windowsgames.co.uk)
by Andrea Usai (n-drx@libero.it)


DETAILS
made on: 01.2005
size: 990x675
continents: 9
territories: 48
scroll: none
wrap: no

IF YOU LIKE THIS MAP, TRY ALSO...		BECAUSE OF...
"On Target" by Mike Crush			Territories are sectors of a circle.

MAPS BY THE SAME AUTHOR
#1 08.2004 - AuSlayWorld
#2 09.2004 - AuRatsMaze
#3 12.2004 - AuIsometric
#4 01.2005 - AuTheGeneral
#5 01.2005 - Au3dMap
#6 01.2005 - AuCircles


ALL MAPS ARE AVAILABLE AT: www.windowsgames.co.uk/conquest_maps.html