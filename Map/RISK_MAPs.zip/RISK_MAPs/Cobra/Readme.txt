Created by Jeff S
Map #6: Cobra

I have been trying to make this map for a while and it never seemed to turn out right until now. The "continents" are
separated by the darker black lines. The head area is worth 2, the next area down called the body is worth 3, the stomach
(the area to the bottom of the map) is worth 3, the back is worth 3, and the tail end near the top of the screen by the
head is worth 2. There are two other connections between the area drawn in by the red lines.

If you would like more maps made by Me or other map makers, go to this web address:

http://www.windowsgames.co.uk/conquest_maps.html

Have fun!