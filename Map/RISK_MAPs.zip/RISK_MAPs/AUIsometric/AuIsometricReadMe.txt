AuIsometric
-----------
map for Conquest (www.windowsgames.co.uk)
by Andrea Usai (n-drx@libero.it)


MAP DETAILS
made on: 12.2004
size: 1026x676
continents: 5
territories: 65
scroll: horizontal

MAP ADDITIONAL DETAILS
- Territories are marked by black lines, the gray lines only serve to give the 3d aspect.
- Continent borders can be passed by the armies, even if their aspect suggests the opposite.
- Some territories have a teleport, which allows your armies to reach any other territory with a teleport in it.
- The names of all territories are fictious, though derived from names of existing localities:
  Map continent		Source country
  Deutaat		Germany
  Entate		U.K.
  Espado		Spain
  Fretat		France
  Istatia		Italy
- The names of the continents are a combination of the name of the country and the word "State" in its language.
- This map should be played on Conquest version 3.0 (or higher).

MAPS BY THE SAME AUTHOR
#1 08.2004 - AuSlayWorld
#2 09.2004 - AuRatsMaze
#3 12.2004 - AuIsometric

IF YOU LIKE THIS MAP TRY ALSO...		BECAUSE OF...
"3D Cliff" by Tim Martin			3d aspect
"Di'Mul_Jar" and "Twin Volcano" by Ekij		mini-map with continent values
Some maps by Mike Crush (i.e. "The S Map")	(sort of) teleports


ALL MAPS ARE AVAILABLE AT: www.windowsgames.co.uk/conquest_maps.html