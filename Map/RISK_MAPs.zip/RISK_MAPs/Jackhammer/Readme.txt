Created by Jeff S
Map #8: Jackhammer

This is a small and furious battle map. There are no continents, and a very small margin for error in your tactics. Each territory connects to all the other territories except for the two around it. Try playing with 8 players on very clever to play the map at its max potential.

If you would like more maps made by Me or other map makers, go to this web address:

http://www.windowsgames.co.uk/conquest_maps.html

Have fun!