Created by Jeff S, Mike Crush, Ashley, Helena

This map is very unique. Each person created a section and they were linked together. Here's a breakdown on how to play:

----Top Left Map----
This section was created by Jeff S. Each of the territories with boats connect to eachother. Each of the territories with planes connect to eachother. The purple star connects to all the other purple stars on the map. There is one purple star per section. The territory on the bottom right connects to all the other territories on the other sections with the dotted line.

----Top Right Map----
This section was created by Ashley. The blue stars connect to the middle green star. The yellow stars connect to the red stars. The green star in the middle connects to all the blue stars along with the red stars, but the red stars do not connect back to it. The purple star connects to the purple star on each section of the map. The territory on the bottom left connects to the other territories from each section that the dotted line connects to. This section is very strategical.

----Bottom Left Map----
This section was created by Helena. The territories with the whirl connect to eachother. The purple star connects to the purple star found on each map. The top right territory connects to the territories that connect to the middle dotted line. This is a fun section to pick up some continent points.

----Bottom Right Map----
This section was created by Mike Crush. Each of the colored squares on the square triangle connect to the places on the right side. Capture those areas for points. The purple star connects to the purple star on each section of the map. The top left territory connects to territories on the other maps connected to the middle dotted line. This map is very tactical.

If you don't understand how to play parts of this map, try playing it through a couple more times. It usually helps your understanding of the map. If you still don't understand, post on the message boards on Sean's site and we will help you as much as we can.

Note: This map has a vertical wrap to help those with smaller monitors.

Note: This is Jeff's map #9 in his series. Mike Crush, Helena, and Ashley also helped to create this. Mike has a very large series of maps, and Helena and Ashley each have a series of maps also. Download them and check them out, they are all very fun!

If you would like more maps made by US or other map makers, go to this web address:

http://www.windowsgames.co.uk/conquest_maps.html

Have fun!