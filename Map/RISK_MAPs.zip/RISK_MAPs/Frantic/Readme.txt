Created by Jeff S
Map #10: Frantic

MAKE SURE YOU HAVE AT LEAST VERSION 2.1C OF CONQUEST OR THIS MAP WILL NOT WORK AT ALL OR IT WILL GET SOME ERRORS!!!!
Click help, and go to about and it should list your version number. If you dont have version 2.1c and this map does not work, email sean
at sean@windowsgames.co.uk for version 2.1c. This version lets maps have more than 128 territories and fixes many errors some maps get.

This map consists of three smaller maps I've been wanting to make, only combined into a great map.

Note: Sometimes when placing down your initial starting armies, you are forced to hit finish attacks and finish move. Just keep doing it until your initial armies are down, no one can attack eachother. This may also happen while you are picking the territories themselves. In this case, you may not be able to put down any initial armies, but this is usually due to only having a few opponents. Therefore, you will have a lot of territories and you can place down a lot of armies your first turn anyways.

----GENERAL INFO----
Throughout the map, all green outlined territories connect, all airplane territories connect, all red sideways 8s connect, and all territories with the random blue symbol connect. These are the only ways the three map sections connect, territories on the edge of each map do not connect to eachother. If you would like to know how much each continent is worth, go to view and continent scores. I realize this map may be a bit confusing but you will get the hang of it in no time. Please read about each map section below for a more thorough understanding.

----GREEN SECTION----
This was originally going to be its own map but I pulled it back cause it had some problems and put it into this map. The red circled territories connect, as well as the blue circled territories. The pink circled territory in the middle can attack all blue and red circled territories besides the two in the center of the map. The pink circled territory is also circled in green allowing it to attack the green outlined territories on the other sections of this map. The red sideways 8s connect to all the other ones on the map, along with the blue symbol, and the airplane.

----BLUE SECTION----
I began creating this map while I was making the map in the purple section, and decided to pull these three maps together for an awesome map. It is divided into four continents. They include the large circle, along with the smaller circle in the middle. For example, the circle on the top and the smaller circle directly below it are a continent. The small circles in the middle connect to the larger ones at the closest territory on the larger circle. The four innermost territories outlined in green all connect to all other green outlined territories on the rest of the map, as well as eachother. Just like the other sections, the airplanes, sideways 8s, and blue symbols also connect to the other section's territories with the same symbol.

----PURPLE SECTION----
This is a smaller section of the map consisting of only one continent, but some furious battles. Same rules apply as the other sections. The airplane territory connects to the other maps, along with the sideways 8 and the blue symbol.


If you would like more maps made by Me or other map makers, go to this web address:

http://www.windowsgames.co.uk/conquest_maps.html

Have fun!