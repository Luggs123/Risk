 AuSlayWorld
-----------
map for Conquest (www.windowsgames.co.uk)
by Andrea Usai (n-drx@libero.it)


MAP DETAILS
made on: 08.2004
size: 650x445
continents: 7
territories: 41
scroll: horizontal

MAP ADDITIONAL DETAILS
- This map is dedicated to the game "Slay" by Sean O'Connor. It uses trees, huts and sea graphics from that game.
- This is my first map!

MAPS BY THE SAME AUTHOR
#1 08.2004 - AuSlayWorld
#2 09.2004 - AuRatsMaze

IF YOU LIKE THIS MAP TRY ALSO...		BECAUSE OF...
"Slay-esque" by Zworg2				same theme
"AuRatsMaze" by Andrea Usai			use of graphics from a game


ALL MAPS ARE AVAILABLE AT: www.windowsgames.co.uk/conquest_maps.html