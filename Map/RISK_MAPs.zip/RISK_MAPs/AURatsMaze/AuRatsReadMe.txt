AuRatsMaze
----------
map for Conquest (www.windowsgames.co.uk)
by Andrea Usai (n-drx@libero.it)


MAP DETAILS
made on: 09.2004
size: 642x720
continents: 10
territories: 47
scroll: vertical

MAP ADDITIONAL DETAILS
- This map is dedicated to the game "Rats" by Sean O'Connor. All graphics come from that game.
- Gas and No-entry signs separate territories. Armies can move only through gas and tunnels.

BONUS: PLAY AuRatsMaze IN RATS!
* Create a backup copy of the Level.lvl file found in your Rats folder;
* With an hex editor open both the original Level.lvl and AuRatsMaze.dat (the latter should be in the map zip archive);
* Copy the content of the dat file (1024 bytes) and paste it into the lvl file starting from offset 0.
* Start Rats and have fun!
(Note that some tunnels were removed in order to make the map play properly.)

MAPS BY THE SAME AUTHOR
#1 08.2004 - AuSlayWorld
#2 09.2004 - AuRatsMaze

IF YOU LIKE THIS MAP TRY ALSO...		BECAUSE OF...
"AuSlayWorld" by Andrea Usai			use of graphics from a game
"Slay-esque" by Zworg2				both inspired to a game


ALL MAPS ARE AVAILABLE AT: www.windowsgames.co.uk/conquest_maps.html