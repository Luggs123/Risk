Created by Jeff S
Map #8: Jackhammer

Dedicated to Bill Golderg, the best wrestler EVER.

The map is separated by groups of circles. Continents are determined by each group.
How much the continent is worth is equivalent to how many circles are in it.
The continents connect by the red lines, and the left side of the map connects
to the right through the red and green circle in continents 6 and 7.
This is an intense map best played with humans. With computers they usually
just let you take the right side of the map so you can easily win. With humans,
dont let anyone control an area for too long or they will win.

If you would like more maps made by Me or other map makers, go to this web address:

http://www.windowsgames.co.uk/conquest_maps.html

Have fun!