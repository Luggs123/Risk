Created by Jeff S
Map #3: Island Hopping

You should download the latest version of Risk from Sean to play this map at its best. It may get rid of many "resupplying ai" errors and errors like it. These will not harm your game or your computer, they will just give the enemy extra armies sometimes or give you armies on random territories you own.

This map has added scenery to give it a more interesting look. It didn't turn out to well but it feels more colorful. The areas marked by an airplane are all connected to each other, and the same goes for the boats. This makes for an interesting map, because you can travel around to different areas of the map without having to conquer most of the map to get to where you want. It also allows you to get attacked from some unexpected areas. The person owning the area getting blasted by the volcano loses one guy a turn, but that territory is needed to own the continent, which allows for an interesting twist. To see how much the continents are worth, click view, then continent scores. Most of the names are based on their location on the map.

Note: Sometimes in a longer game you might get an error saying something like "resupplying AI". This is harmless, usually you will get extra guys on random territories, no harm done. I have no idea why the map sometimes does this.

If you would like more maps made by Me or other map makers, go to this web address:

http://www.windowsgames.co.uk/conquest_maps.html

Have fun!