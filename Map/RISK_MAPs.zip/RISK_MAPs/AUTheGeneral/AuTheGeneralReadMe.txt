AuTheGeneral
------------
map for Conquest (www.windowsgames.co.uk)
by Andrea Usai (n-drx@libero.it)


MAP DETAILS
made on: 01.2005
size: 995x646
continents: 8
territories: 86
scroll: vertical
wrap: no

MAP ADDITIONAL DETAILS
- This map is dedicated to the game "The General" by Sean O'Connor. Flag, Bomb and General graphics come from that game.

IF YOU LIKE THIS MAP, TRY ALSO...		BECAUSE OF...
"Against All Odds" by Mike Crush		squared territories and map, negative territories
"The S Map" by Mike Crush			squared territories, negative and positive territories
"All For One" by Mike Crush			squared territories and map
"AuSlayWorld" by Andrea Usai			inspired to a game by Sean O'Connor
"AuRatsMaze" by Andrea Usai			inspired to a game by Sean O'Connor

MAPS BY THE SAME AUTHOR
#1 08.2004 - AuSlayWorld
#2 09.2004 - AuRatsMaze
#3 12.2004 - AuIsometric
#4 01.2005 - AuTheGeneral


ALL MAPS ARE AVAILABLE AT: www.windowsgames.co.uk/conquest_maps.html