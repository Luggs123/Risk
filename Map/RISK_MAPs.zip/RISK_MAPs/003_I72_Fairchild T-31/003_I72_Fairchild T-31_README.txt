Known bugs with this map:  You can attack from Territory 53 to Territory 55 but the reverse is not possible.  It is odd and I am not sure what causes it.  Perhaps Sean knows, but I certainly am in the dark on this one.

Iceworm72
