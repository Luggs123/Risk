Created by Jeff S
Map #11: Stunner

Dedicated to Stone Cold Steve Austin, the best wrestler EVER.

Each of the islands is connected by the red dotted lines.
The only way to attack from the outside islands to the middle one
is through the ovals outlined in blue. Each of the island's ovals
can attack the middle but not eachother. The middle oval can attack
all of them. Check the continent values in the menu. Ring 1 is closest
to the middle oval, ring 2 is outside of that, and ring 3 is outside of
ring 2. All of the continents are named by their location.

If you would like more maps made by Me or other map makers, go to this web address:

http://www.windowsgames.co.uk/conquest_maps.html

Have fun!