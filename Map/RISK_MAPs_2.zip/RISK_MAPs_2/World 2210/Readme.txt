Created by Jeff S
Map #5: World 2210

You probably didn't know, but there has been a new version of risk out for purchase for some time now. It is called Risk 2210 A.D. It takes place in the future. You can't find it at many stores, but you can buy it online. It has new territories in the water, as well as a moon board you can go to. Many other things such as battle cards, money, space stations, and the purchasing of commander make this game a lot more exciting and complicated. This is the Earth part of the game. I have also created the Moon portion for download, so if you want it, check out the site below. You may not see much of a difference besides the water territories at first, but there also some other things different. Every territory has a new name now. No I did not make these up, that is what they are called in the real game. Greenland now only connects to two territories in North America instead of three, and the Middle East only connects to one place in Africa, rather than two. This map is very hard, especially with 7 other very clever computers. The new continents are named after the real game also, usually the name reflects their location on the planet.
For more information on this game, and to see that im not making this all up, please check out these websites:

http://boardgames.about.com/library/weekly/aa071701a.htm
http://www.avalonhill.com/default.asp?x=games/risk


If you would like more maps made by Me or other map makers, go to this web address:

http://www.windowsgames.co.uk/conquest_maps.html

Have fun!