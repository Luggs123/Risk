Created by Jeff S
Map #4: Moon

You probably didn't know, but there has been a new version of risk out for purchase for some time now. It is called Risk 2210 A.D. It takes place in the future. You can't find it at many stores, but you can buy it online. It has new territories in the water, as well as a moon board you can go to. Many other things such as battle cards, money, space stations, and the purchasing of commander make this game a lot more exciting and complicated. This is the moon part of the game. I have also created the Earth portion for download, so if you want it, check out the site below. Please go to view and continent scores to see how much each continent is worth, you may want to play a little first to know what the continent names are first. This map may seem lame, but try playing with 7 computers on very clever. You may get eliminated within 2 turns!! This map offers up some fast and furious battles!
For more information on this game, and to see that im not making this all up, please check out these websites:

http://boardgames.about.com/library/weekly/aa071701a.htm
http://www.avalonhill.com/default.asp?x=games/risk


If you would like more maps made by Me or other map makers, go to this web address:

http://www.windowsgames.co.uk/conquest_maps.html

Have fun!