Created by Jeff S
Map #2: Swirl

This complex map can put up quite a challenge. The outermost areas enclosed in thicker lines are continents. The remaining area in that quarter of the circle are also continents. The four middle territories connect. The scoring is based how many places are needed to be defended when the continent is acquired, and also by how many territories that are in the continents.

If you would like more maps made by Me or other map makers, go to this web address:

http://www.windowsgames.co.uk/conquest_maps.html

Have fun!