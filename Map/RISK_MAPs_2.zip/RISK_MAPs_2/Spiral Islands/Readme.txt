Created by Jeff S
Map #1: Spiral Islands

The middle island is worth 15 armies per turn. The Islands around it are paired up into 4 different continents. The arrows directed off from each number 9 are connected as one, and are worth 9 armies per turn. The east and west islands are both worth 5 armies per turn, while the corner islands are valued at 3 armies per turn.

If you would like more maps made by Me or other map makers, go to this web address:

http://www.windowsgames.co.uk/conquest_maps.html

Have fun!